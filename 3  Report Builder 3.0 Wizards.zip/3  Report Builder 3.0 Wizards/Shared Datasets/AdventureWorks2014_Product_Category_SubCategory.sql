SELECT
  Production.Product.ProductID
  ,Production.Product.Name
  ,Production.Product.ListPrice
  ,Production.ProductCategory.ProductCategoryID AS [ProductCategory ProductCategoryID]
  ,Production.ProductSubcategory.ProductSubcategoryID
  ,Production.ProductSubcategory.ProductCategoryID AS [ProductSubcategory ProductCategoryID]
FROM
  Production.ProductSubcategory
  INNER JOIN Production.Product
    ON Production.ProductSubcategory.ProductSubcategoryID = Production.Product.ProductSubcategoryID
  INNER JOIN Production.ProductCategory
    ON Production.ProductSubcategory.ProductCategoryID = Production.ProductCategory.ProductCategoryID